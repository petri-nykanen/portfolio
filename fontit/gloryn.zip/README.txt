Gloryn ver 1.1 (donationware)

Gloryn is the first regular family version that I shared with the public
after more than a year I myself taught how to create fonts, explored
font design until this font was born. The other Gloryn Family is still
a work in progress. I would love it if users could find flaws in this work
to make it better like the professional fonts that are out there.

For personal use and non profit project you can use for free.
For commercial use, you can use after donating in the amount I deserve.
I really appreciate every donation sent.

Support donation to my PayPal address : nicofarentinno@gmail.com

Thanks,

Nico Farentinno
(orchstrdsgn)  

